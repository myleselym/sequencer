"use client";
import "./Piano.css";
import WhiteKey from "./keys/WhiteKey";
import BlackKey from "./keys/BlackKey";
import { Dispatch, SetStateAction } from "react";
import { ChromaticScaleData } from "@/data/scale-data";

type Scale = string[];


type Props = {
    octaves: number;
    scale: Scale;
    focusedNote: string;
    chromaticScaleData: ChromaticScaleData;
    setOctaves: Dispatch<SetStateAction<number>>;
    setScale: Dispatch<SetStateAction<string[]>>;
    setFocusedNote: Dispatch<SetStateAction<string>>;
};

const Piano = ({ scale, setScale, chromaticScaleData, focusedNote, setFocusedNote }: Props) => {
    const isScaleTone = (note: string) => scale.includes(note);
    const renderWhiteKey = (index: number) => (
        <WhiteKey
            key={index}
            note={chromaticScaleData.scale[index].note + chromaticScaleData.scale[index].octave}
            scaleTone={isScaleTone(chromaticScaleData.scale[index].note)}
            activeKey={focusedNote}
            setActiveKey={setFocusedNote}
        />
    );

    const renderBlackKey = (index: number) => (
        <BlackKey
            key={index}
            note={chromaticScaleData.scale[index].note + chromaticScaleData.scale[index].octave}
            scaleTone={isScaleTone(chromaticScaleData.scale[index].note)}
            activeKey={focusedNote}
            setActiveKey={setFocusedNote}
        />
    );

    return (
        <section id="piano">
            {chromaticScaleData.scale.map((_, i) => {
                if (i % 12 === 0 && i !== chromaticScaleData.scale.length - 1) {
                    return (
                        <div key={i} className="octave">
                            {renderWhiteKey(i)}
                            {renderBlackKey(i + 1)}
                            {renderWhiteKey(i + 2)}
                            {renderBlackKey(i + 3)}
                            {renderWhiteKey(i + 4)}
                            {renderWhiteKey(i + 5)}
                            {renderBlackKey(i + 6)}
                            {renderWhiteKey(i + 7)}
                            {renderBlackKey(i + 8)}
                            {renderWhiteKey(i + 9)}
                            {renderBlackKey(i + 10)}
                            {renderWhiteKey(i + 11)}
                        </div>
                    );
                } else if (i === chromaticScaleData.scale.length - 1) {
                    return (
                        <div key={i} className="octave">
                            {renderWhiteKey(i)}
                        </div>
                    );
                }
            })}
        </section>
    );
};

export default Piano;
