"use client"

import "../Piano.css"
type Props = {note: string, scaleTone: boolean, activeKey:string, setActiveKey: (note: string) => void}
const WhiteKey = ({note, scaleTone, activeKey, setActiveKey}:Props) => {
    const handleKeyClick = () => {
        console.log(note)
        setActiveKey(note)
    }
    return (
        <div 
        onClick={handleKeyClick}
        data-note={note}
        className={`white-key ${scaleTone && "scale-tone"} ${activeKey === note && "active-piano-key"} ${note}` }
        >
        </div>
    )
}

export default WhiteKey;