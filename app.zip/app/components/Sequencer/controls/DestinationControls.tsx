import { useEffect, useState } from "react";
import { getContext } from "tone";

type Props = {
}

const DestinationControls = ({ }:Props) => {
    const [volume, setVolume] = useState<number>(-6);

    const handleVolume = (e: React.ChangeEvent<HTMLInputElement>) => {
        setVolume(parseInt(e.target.value));
    };

    useEffect(() => {
        getContext().destination.volume.rampTo(volume);
    }, [volume]);
    return (
        <section id="destination-controls">
            <label htmlFor="volume-slider" >Volume</label>
            <input id="volume-slider" type="range" min={-40} max={0} value={volume} onChange={handleVolume} />
        </section>
    );
};

export default DestinationControls;