"use client"
import { useEffect, useState, useRef, Dispatch, SetStateAction } from 'react';
import { Sequence, Synth, SynthOptions, PolySynth, getDraw, Limiter } from 'tone';
import { RecursivePartial } from 'tone/build/esm/core/util/Interface';
import { notes } from '@/data/scale-data';
import { GridData } from '@/data/grid-data';
import TransportControls from './controls/TransportControls';
import DestinationControls from './controls/DestinationControls';
import SynthControls from './controls/SynthControls';
import "./Sequencer.css"

type Props = {
    gridData: GridData;
    setActiveRow: Dispatch<SetStateAction<number | null>>;
}

const initSynthSettings: RecursivePartial<SynthOptions> = {
    volume: -12,
    detune: 0,
    portamento: 0,
    oscillator: {
        type: 'sine',
        phase: 0,
        partialCount: 0,
    },
    envelope: {
        attack: 0.05,
        decay: 0.3,
        sustain: 0.1,
        release: 0.1,
    },
};

const Sequencer = ({ gridData, setActiveRow }: Props) => {
    const [loaded, setLoaded] = useState(false);
    const [synthSettings, setSynthSettings] = useState(initSynthSettings);
    const synthsRef = useRef<{[key:string]: PolySynth}>({});
    const sequenceRef = useRef<Sequence | null>(null);

    // Initialize synths only once
    useEffect(() => {
        if (!loaded) return;
        if (Object.keys(synthsRef.current).length === 0) {
            notes.forEach((note) => {
                synthsRef.current[note] = new PolySynth(Synth).toDestination();
            });
            // Apply initial settings to all synths
            Object.keys(synthsRef.current).forEach((synthKey) => {
                synthsRef.current[synthKey].set(synthSettings);
            });
            console.log(synthsRef.current)
        }
    }, [loaded, synthSettings]);

    useEffect(() => {
        // Apply settings when synthSettings change
        Object.keys(synthsRef.current).forEach((synthKey) => {
            synthsRef.current[synthKey].set(synthSettings);
        });
    }, [synthSettings]);

    useEffect(() => {
        const gridCellData = gridData.gridCellData;
        const initTone = async () => {
            const sequence = new Sequence((time, col) => {
                getDraw().schedule(() => {
                    setActiveRow(col)
                    console.log(col)
                }, time)
                gridCellData[col].forEach((cell) => {
                    if (cell.active) {
                        const triggerNote = cell.note + cell.octave;
                        synthsRef.current[cell.note].triggerAttackRelease(triggerNote, "16n", time, cell.velocity);
                    }
                });
            }, Array.from({ length: gridCellData.length }, (_, i) => i), "16n");
            sequenceRef.current = sequence;
            return () => {
                sequence.dispose();
            };
        };
        initTone();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [gridData]);

    return (
        <section id="sequencer">
            <TransportControls setLoaded={setLoaded} sequenceRef={sequenceRef} />
            <DestinationControls />
            <SynthControls synthSettings={synthSettings} setSynthSettings={setSynthSettings} />
        </section>
    );
};

export default Sequencer;
