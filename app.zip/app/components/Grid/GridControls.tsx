// GridControls.tsx
import { GridData, createGridData } from "@/data/grid-data";
import { ChromaticScaleData } from "@/data/scale-data";
import { ChangeEvent, Dispatch, SetStateAction, useState } from "react";
import "./Grid.css";

type Props = {
    steps: number;
    gridData: GridData;
    chromaticScaleData: ChromaticScaleData;
    setSteps: Dispatch<SetStateAction<number>>;
    setGridData: Dispatch<SetStateAction<GridData>>;
    resetFocus: () => void;
};

const initialPatternName = "Pattern-1";

const GridControls = ({
    steps,
    gridData,
    chromaticScaleData,
    setSteps,
    setGridData,
    resetFocus
}: Props) => {
    const [currentPattern, setCurrentPattern] = useState<string>(initialPatternName);
    const [userPatterns, setUserPatterns] = useState<{ [patternName: string]: GridData }>({ "Pattern-1": gridData });

    const savePattern = (patternName: string, patternData: GridData) => {
        setUserPatterns((prev) => ({
            ...prev,
            [patternName]: patternData
        }));
    };

    const renamePattern = (oldPatternName: string, newPatternName: string) => {
        setUserPatterns((prev) => {
            const newUserPatterns = { ...prev };
            newUserPatterns[newPatternName] = newUserPatterns[oldPatternName];
            delete newUserPatterns[oldPatternName];
            return newUserPatterns;
        });
        if (currentPattern === oldPatternName) {
            setCurrentPattern(newPatternName);
        }
    };

    const handleNewGridData = () => {
        const newPatternName: string = prompt("Enter pattern name", `Pattern-${Object.keys(userPatterns).length + 1}`) || currentPattern;
        if (newPatternName in userPatterns) {
            alert("Pattern name already exists. Please choose a different name.");
            return;
        }
        // Save the current pattern before creating a new one
        savePattern(currentPattern, gridData);
        // Create and set new pattern
        const newGridData = createGridData(chromaticScaleData.scale, steps);
        setGridData(newGridData);
        setCurrentPattern(newPatternName);
        savePattern(newPatternName, newGridData);
        resetFocus();
    };

    const handlePatternChange = (e: ChangeEvent<HTMLSelectElement>) => {
        const patternName = e.target.value;
        setCurrentPattern(patternName);
        setGridData(userPatterns[patternName]);
        resetFocus();
    };

    return (
        <div id="grid-controls">
            <label htmlFor="steps-select">Steps:</label>
            <input
                id="steps-select"
                type="number"
                value={steps}
                onChange={(e) => setSteps(parseInt(e.target.value))}
                style={{ color: "black" }}
                min="4"
                max="64"
            />
            <label htmlFor="pattern-select">Pattern:</label>
            <select id="pattern-select" value={currentPattern} onChange={handlePatternChange}>
                {Object.keys(userPatterns).map((patternName) => (
                    <option key={patternName} value={patternName}>{patternName}</option>
                ))}
            </select>
            <button onClick={handleNewGridData}>New</button>
            <button onClick={() => renamePattern(currentPattern, prompt("Enter new pattern name", currentPattern) || currentPattern)}>Rename</button>
        </div>
    );
};

export default GridControls;
