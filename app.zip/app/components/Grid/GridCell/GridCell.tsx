"use client";

import { GridData } from "@/data/grid-data";
import { Dispatch, SetStateAction, useState } from "react";
import {memo} from 'react';

type Props = {
    note: string;
    octave: number;
    rowIndex: number;
    colIndex: number;
    gridData: GridData;
    hoverRowCol: (number | null)[];
    focusedRow: number | null;
    scaleTone: boolean;
    focusedNote: string;
    setGridData: Dispatch<SetStateAction<GridData>>;
    setHoverRowCol: (rowIndex: number | null, colIndex: number | null) => void;
    setFocusedNote: Dispatch<SetStateAction<string>>;
};

const scrollStep = 5;

const GridCell = (({
    note,
    octave,
    rowIndex,
    colIndex,
    gridData,
    hoverRowCol,
    focusedRow,
    scaleTone,
    focusedNote,
    setGridData,
    setHoverRowCol,
    setFocusedNote
}: Props) => {
    const gridCellData = gridData.gridCellData;
    const velocity = gridCellData[rowIndex][colIndex].velocity;

    const handleClick = () => {
        setFocusedNote(note + octave);
        const active = !gridCellData[rowIndex][colIndex].active;
        setGridData((prev: any) => {
            const newGridData = {...prev};
            newGridData.gridCellData[rowIndex][colIndex].active = active;
            return newGridData;
        });
    };

    const handleWheel = (e: React.WheelEvent) => {
        if (e.shiftKey) {
            setGridData((prev: any) => {
                const newGridData = {...prev};
                const newGridCellData = [...newGridData.gridCellData];
                const newVelocity = newGridCellData[rowIndex][colIndex].velocity + (e.deltaY > 0 ? -scrollStep : scrollStep);
                newGridCellData[rowIndex][colIndex].velocity = Math.max(0, Math.min(120, newVelocity));
                return newGridData;
            });
        }
    };

    return (
        <div
            onClick={handleClick}
            onWheel={handleWheel}
            onMouseOver={() => setHoverRowCol(rowIndex, colIndex)}
            onMouseOut={() => setHoverRowCol(null, null)}
            data-note={note}
            className={`grid-cell 
                        ${focusedNote === note + octave && "focused-cell"} 
                        ${scaleTone && "scale-tone-cell"} 
                        ${focusedRow === rowIndex && "focused-row"}
                        ${(hoverRowCol[0] === rowIndex || hoverRowCol[1] === colIndex) && "hover-row-col"}
                        `}
            style={{ backgroundColor: gridCellData[rowIndex][colIndex].active ? `rgb(${135 + velocity}, ${velocity % 40}, ${255 - velocity})` : undefined }}
        >
            {note + octave}
        </div>
    );
});

export default memo(GridCell);
