"use client"
import { Dispatch, SetStateAction, useState, useCallback, ChangeEvent } from "react"
import GridCell from "./GridCell/GridCell"
import { GridData, createGridData} from "@/data/grid-data"
import { ChromaticScaleData } from "@/data/scale-data"
import GridControls from "./GridControls"
import "./Grid.css"

type Props = {
    steps: number,
    octaves: number,
    scale: string[],
    chromaticScaleData: ChromaticScaleData, 
    gridData: GridData,
    activeRow: number | null,
    focusedNote:string,
    setSteps: Dispatch<SetStateAction<number>>,
    setGridData: Dispatch<SetStateAction<GridData>>
    setFocusedNote: Dispatch<SetStateAction<string>>,
}

const Grid = ({steps, octaves, scale, chromaticScaleData, gridData, activeRow, focusedNote, setSteps, setGridData, setFocusedNote}: Props) => {
    const [focusedRow, setFocusedRow] = useState<number | null>(null);
    const [hoverRowCol, setHoverRowCol] = useState<(number|null)[]>([null, null]);
    

    const handleSetHoverRowCol = (rowIndex: number | null, colIndex: number | null) => {
        setHoverRowCol([rowIndex, colIndex]);
    };

    const resetFocus = () => {
        setFocusedRow(null);
        setFocusedNote("");
    }

    
    return (
        <section id="grid">
            <GridControls
                steps={steps}
                gridData={gridData}   
                chromaticScaleData={chromaticScaleData}
                setSteps={setSteps}
                setGridData={setGridData}
                resetFocus={resetFocus}
            />

            {gridData.gridCellData.map((row, rowIndex) => (
                <div key={rowIndex} id={"grid-row-" + rowIndex} className={`grid-row ${activeRow === rowIndex && "active-row"}`} onClick={() => setFocusedRow(rowIndex)}>
                    {row.map((cell, colIndex) => (
                        <GridCell 
                            key={cell.note + colIndex}
                            rowIndex={rowIndex}
                            colIndex={colIndex}
                            note={cell.note}
                            octave={cell.octave}
                            gridData={gridData}
                            setGridData={setGridData}
                            hoverRowCol={hoverRowCol}
                            scaleTone={scale.includes(cell.note)} 
                            focusedRow={focusedRow}
                            focusedNote={focusedNote} 
                            setFocusedNote={setFocusedNote}
                            setHoverRowCol={handleSetHoverRowCol}
                        />
                    ))}
                </div>
            ))}
        </section>
    );
}

export default Grid;
