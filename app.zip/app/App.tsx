"use client"
import {ChromaticScaleData, createChromaticScale, createScale, notes} from "../data/scale-data"
import Grid from "./components/Grid/Grid"
import Piano from "./components/Piano/Piano"
import { useState } from "react"
import { GridData, createGridData } from "@/data/grid-data"
import Sequencer from "./components/Sequencer/Sequencer"
import "./App.css"

// Initial Data
const initOctaves = 4;
const initRootNote = "C#"
const initScaleType = "Ionian"
const initScale = createScale(initRootNote, initScaleType, initOctaves)
const initChromaticScale = createChromaticScale(initOctaves)
const initSteps = 16
const initGridData = createGridData(initChromaticScale.scale, initSteps)

const App = () => {
  const [octaves, setOctaves] = useState<number>(initOctaves)
  const [scale, setScale] = useState<string[]>(initScale)
  const [chromaticScaleData, setChromaticScaleData] = useState<ChromaticScaleData>(initChromaticScale)
  const [focusedNote, setFocusedNote] = useState<string>("")
  const [steps, setSteps] = useState<number>(initSteps)
  const [gridData, setGridData] = useState<GridData>(initGridData)
  const [activeRow, setActiveRow] = useState<number | null>(null)


  return (
    <article id="grid-sequencer">
      <Grid
        steps={steps}
        octaves={octaves} 
        scale={scale} 
        chromaticScaleData={chromaticScaleData} 
        activeRow={activeRow} 
        gridData={gridData} 
        focusedNote={focusedNote} 
        setSteps={setSteps}
        setGridData={setGridData} 
        setFocusedNote={setFocusedNote}
      />
      <Sequencer 
        gridData={gridData} 
        setActiveRow={setActiveRow} 
      />
      <Piano 
        octaves={octaves}
        scale={scale} setScale={setScale} 
        chromaticScaleData={chromaticScaleData} 
        focusedNote={focusedNote} 
        setOctaves={setOctaves}
        setFocusedNote={setFocusedNote} 
      />
    </article>
  )
}

export default App