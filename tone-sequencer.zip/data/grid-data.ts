type GridData = [{note: string, cells:[active:boolean, velocity:number]}]

type CellData = {
    note: string;
    octave: number;
    active: boolean;
    velocity: number;
};
const cellData = {
    note: "",
    octave: 0,
    active: false,
    velocity: 60
};

export const createGridData = (scale:{note:string,octave:number}[], steps: number) => {
    const gridData = Array.from({ length: steps }).map(() => {
        return scale.map(({note, octave}, i) => {
            return {
                ...cellData, note, octave
            };
        });
    });
    return gridData;
};