export const notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

export const noteNames = {
    "C": ["C"],
    "C#": ["C#", "Db"],
    "D": ["D"],
    "D#": ["D#", "Eb"],
    "E": ["E"],
    "F": ["F"],
    "F#": ["F#", "Gb"],
    "G": ["G"],
    "G#": ["G#", "Ab"],
    "A": ["A"],
    "A#": ["A#", "Bb"],
    "B": ["B"]
}
export const scaleModeIntervals: {[key:string]: number[]}= {
    "Ionian": [2,2,1,2,2,2,1],
    "Aolian": [2,1,2,2,1,2,2],
    "Dorian": [2,1,2,2,2,1,2],
    "Phrygian": [1,2,2,2,1,2,2],
    "Lydian": [2,2,2,1,2,2,1],
    "Mixolydian": [2,2,1,2,2,1,2],
    "Locrian": [1,2,2,1,2,2,2]
}

export const createScale = (root:string, mode:string, octaves:number) => {
    const rootIndex = notes.indexOf(root) // Index of the root note
    const intervals = scaleModeIntervals[mode] // Interval array of the scale mode
    const scale: string[] = [] // Initialize the scale with the root note
    let currentIndex = rootIndex // Initialize the current note index with the root note index
        for (let interval of intervals) { // Loop through the intervals
            currentIndex = (currentIndex + interval) % 12 // Calculate the index of the next note
            const currentNoteName = notes[currentIndex] // Get the name of the next note
            if (currentIndex >= 0 && currentIndex <= rootIndex) { // Check if the note is in the same octave as the root noteS
                scale.push(currentNoteName)
            } 
            else {
                scale.push(currentNoteName)
            }
        }
    return scale
}

export const createChromaticScale = (octaves:number) => {
    const chromaticScale = []
    // Loop through the octaves, create an array and add all the notes of the chromatic scale for each octave, starting from C1, and conditionally adding "C" + octaves to the end of the array.
    for (let i = 0; i < octaves; i++) {
        notes.forEach((note) => {
            chromaticScale.push({note: note, octave: (i + 1)})
        })
    }
    chromaticScale.push({note: "C", octave: (octaves + 1)})
    return chromaticScale
}

