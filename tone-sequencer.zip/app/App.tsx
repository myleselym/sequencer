"use client"
import {createChromaticScale, createScale, notes} from "../data/scale-data"
import Grid from "./components/Grid/Grid"
import Piano from "./components/Piano/Piano"
import "./App.css"
import { useState } from "react"
import { createGridData } from "@/data/grid-data"
import Sequencer from "./components/Sequencer/Sequencer"

// Initial Data
const initOctaves = 4;
const initRootNote = "D"
const initScaleType = "Ionian"
const initScale = createScale(initRootNote, initScaleType, initOctaves)
const initChromaticScale = createChromaticScale(initOctaves)
const initSteps = 16
const initGridData = createGridData(initChromaticScale, initSteps)

const App = () => {
  const [octaves, setOctaves] = useState<number>(initOctaves)
  const [activeKey, setActiveKey] = useState<string>("")
  const [scale, setScale] = useState<typeof initScale>(initScale)

  const [gridData, setGridData] = useState(initGridData)

  return (
    <article id="grid-sequencer">
      <Grid scale={scale} gridData={gridData} setGridData={setGridData} activeKey={activeKey} setActiveKey={setActiveKey}/>
      <Sequencer gridData={gridData} />
      <Piano octaves={octaves} setOctaves={setOctaves} scale={scale} setScale={setScale} chromaticScale={initChromaticScale} activeKey={activeKey} setActiveKey={setActiveKey} />
    </article>
  )
}

export default App