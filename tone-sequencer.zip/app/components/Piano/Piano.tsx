"use client";
import "./Piano.css";
import WhiteKey from "./keys/WhiteKey";
import BlackKey from "./keys/BlackKey";
import { Dispatch, SetStateAction } from "react";

type Scale = string[];
type ChromaticScale = { note: string, octave: number }[];

type Props = {
    octaves: number;
    setOctaves: Dispatch<SetStateAction<number>>;
    scale: Scale;
    setScale: Dispatch<SetStateAction<string[]>>;
    activeKey: string;
    setActiveKey: (note: string) => void;
    chromaticScale: ChromaticScale;
};

const Piano = ({ scale, setScale, chromaticScale, activeKey, setActiveKey }: Props) => {
    const isScaleTone = (note: string) => scale.includes(note);
    const renderWhiteKey = (index: number) => (
        <WhiteKey
            key={index}
            note={chromaticScale[index].note + chromaticScale[index].octave}
            scaleTone={isScaleTone(chromaticScale[index].note)}
            activeKey={activeKey}
            setActiveKey={setActiveKey}
        />
    );

    const renderBlackKey = (index: number) => (
        <BlackKey
            key={index}
            note={chromaticScale[index].note + chromaticScale[index].octave}
            scaleTone={isScaleTone(chromaticScale[index].note)}
            activeKey={activeKey}
            setActiveKey={setActiveKey}
        />
    );

    return (
        <section id="piano">
            {chromaticScale.map((_, i) => {
                if (i % 12 === 0 && i !== chromaticScale.length - 1) {
                    return (
                        <div key={i} className="octave">
                            {renderWhiteKey(i)}
                            {renderBlackKey(i + 1)}
                            {renderWhiteKey(i + 2)}
                            {renderBlackKey(i + 3)}
                            {renderWhiteKey(i + 4)}
                            {renderWhiteKey(i + 5)}
                            {renderBlackKey(i + 6)}
                            {renderWhiteKey(i + 7)}
                            {renderBlackKey(i + 8)}
                            {renderWhiteKey(i + 9)}
                            {renderBlackKey(i + 10)}
                            {renderWhiteKey(i + 11)}
                        </div>
                    );
                } else if (i === chromaticScale.length - 1) {
                    return (
                        <div key={i} className="octave">
                            {renderWhiteKey(i)}
                        </div>
                    );
                }
            })}
        </section>
    );
};

export default Piano;
