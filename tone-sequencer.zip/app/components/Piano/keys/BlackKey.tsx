import { useState } from "react"
import "../Piano.css"
type Props = {note: string, scaleTone: boolean, activeKey: string, setActiveKey: (note: string) => void}

const BlackKey = ({note, scaleTone, activeKey, setActiveKey}: Props) => {
  const handleClick = () => {
  console.log(note)
  setActiveKey(note)
}
  return (
    <div 
        onClick={handleClick}
        data-note={note} 
        className={`black-key ${note[0]+"-sharp"} ${scaleTone && "scale-tone"} ${activeKey === note && "active-piano-key"}`}
        ></div>
  )
}

export default BlackKey