"use client"
import { useEffect, useState, useRef } from 'react';
import { Sequence, Synth, SynthOptions, PolySynth, PolySynthOptions, getContext } from 'tone';
import { RecursivePartial } from 'tone/build/esm/core/util/Interface';
import "./Sequencer.css"
import TransportControls from './controls/TransportControls';
import DestinationControls from './controls/DestinationControls';
import SynthControls from './controls/SynthControls';
import { notes } from '@/data/scale-data';

type Props = {
    gridData: { note: string, octave: number; active: boolean, velocity: number }[][]
}

const initSynthSettings: RecursivePartial<SynthOptions> = {
    detune: 0,
    portamento: 0,
    oscillator: {
        type: 'sine',
        phase: 0,
        partialCount: 0,
    },
    envelope: {
        attack: 0.02,
        decay: 0.1,
        sustain: 0.01,
        release: 0.1,
    },
};

const Sequencer = ({ gridData }: Props) => {
    const [loaded, setLoaded] = useState(false);
    const [synthSettings, setSynthSettings] = useState(initSynthSettings);
    const synthsRef = useRef<{[key:string]: PolySynth}>({});
    const sequenceRef = useRef<Sequence | null>(null);
    useEffect(() => {
        if (loaded) {
            notes.forEach((note) => {
                synthsRef.current[note] = new PolySynth(Synth).toDestination();
            });
            console.log(synthsRef.current)
        }
    }, [loaded] )

    useEffect(() => {
        Object.keys(synthsRef.current).forEach((synthKey) => {
            synthsRef.current[synthKey].set(synthSettings);
        });
    }, [synthSettings]);

    useEffect(() => {
        const initTone = async () => {
            const sequence = new Sequence((time, col) => {
                gridData[col].forEach((cell) => {
                    if (cell.active) {
                        const triggerNote = cell.note + cell.octave;
                        synthsRef.current[cell.note].triggerAttackRelease(triggerNote, "16n", time, cell.velocity);
                    }
                });
            }, Array.from({ length: gridData.length }, (_, i) => i), "16n");
            sequenceRef.current = sequence;

            return () => {
                sequence.dispose();
            };
        };
        initTone();
    }, [gridData])

    return (
        <section id="sequencer">
            <TransportControls setLoaded={setLoaded} sequenceRef={sequenceRef} />
            <DestinationControls />
            <SynthControls synthSettings={synthSettings} setSynthSettings={setSynthSettings} />
        </section>
    );
};

export default Sequencer;
