import { Dispatch, MutableRefObject, SetStateAction, useEffect, useState } from "react";

import {start, Sequence, getContext, loaded, getDestination } from "tone";

type Props = {
    sequenceRef: MutableRefObject<Sequence<any> | null>;
    setLoaded: Dispatch<SetStateAction<boolean>>;
};

const TransportControls = ({sequenceRef, setLoaded}:Props) => {
    const [playPause, setPlayPause] = useState(false);
    const [tempo, setTempo] = useState<number>(120);

    const handleTempo = (e: React.ChangeEvent<HTMLInputElement>) => {
        setTempo(parseInt(e.target.value));
    };

    const handlePlayPause = async () => {
        if (playPause) {
            getContext().transport.pause();
        } else {
            await start();
            await loaded();
            setLoaded(true);
            getContext().transport.start();
            sequenceRef.current?.start(0);
        }
        setPlayPause(!playPause);
    };

    const handleStop = () => {
        setPlayPause(false);
        sequenceRef.current?.stop(0);
        getContext().transport.stop();
        setLoaded(false);
    };

    useEffect(() => {
        getContext().transport.bpm.value = tempo;
    }, [tempo]);

    return (
        // JSX code for your component goes here
        <section id="transport-controls">
            <button onClick={handlePlayPause}>{playPause ? "Pause" : "Play"}</button>
            <button onClick={handleStop}>Stop</button>
            <label htmlFor="tempo-slider" >Tempo</label>
            <input id="tempo-slider" type="range" min={20} max={500} value={tempo} onChange={handleTempo} />
        </section>
    );
};

export default TransportControls;