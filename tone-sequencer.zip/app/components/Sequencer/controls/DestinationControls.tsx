import { useEffect, useState } from "react";
import { getContext } from "tone";

type Props = {
}

const DestinationControls = ({ }:Props) => {
    const [volume, setVolume] = useState<number>(-40);

    const handleVolume = (e: React.ChangeEvent<HTMLInputElement>) => {
        console.log(e.target.value)
        setVolume(parseInt(e.target.value));
    };

    useEffect(() => {
        getContext().destination.volume.value = volume;
    }, [volume]);
    return (
        <section id="destination-controls">
            <label htmlFor="volume-slider" >Volume</label>
            <input id="volume-slider" type="range" min={-60} max={-20} value={volume} onChange={handleVolume} />
        </section>
    );
};

export default DestinationControls;