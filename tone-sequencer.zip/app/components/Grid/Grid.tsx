"use client"
import { Dispatch, SetStateAction, useState, useCallback } from "react"
import "./Grid.css"
import GridCell from "./GridCell/GridCell"

type Props = {
    scale: string[], 
    gridData: {note: string, octave: number; active: boolean, velocity:number}[][],
    activeKey:string, 
    setActiveKey: (note:string) => void,
    setGridData: Dispatch<SetStateAction<{note: string, octave: number, active: boolean, velocity:number}[][]>>
}

const Grid = ({scale, gridData, setGridData, activeKey, setActiveKey}: Props) => {
    const [activeRow, setActiveRow] = useState<number | null>(null);
    const [hoverRowCol, setHoverRowCol] = useState<(number|null)[]>([null, null]);

    const handleSetHoverRowCol = useCallback((rowIndex: number | null, colIndex: number | null) => {
        setHoverRowCol([rowIndex, colIndex]);
    }, []);

    return (
        <section id="grid">
            {gridData.map((step, i) => (
                <div key={i} id={"grid-row-" + i} className={`grid-row`} onClick={() => setActiveRow(i)}>
                    {step.map((cell, j) => (
                        <GridCell 
                            key={cell.note + j}
                            rowIndex={i}
                            colIndex={j}
                            note={cell.note}
                            octave={cell.octave}
                            gridData={gridData}
                            setGridData={setGridData}
                            hoverRowCol={hoverRowCol}
                            setHoverRowCol={handleSetHoverRowCol}
                            activeRow={activeRow}
                            scaleTone={scale.includes(cell.note)} 
                            activeKey={activeKey} 
                            setActiveKey={setActiveKey}
                        />
                    ))}
                </div>
            ))}
        </section>
    );
}

export default Grid;
