"use client";

import { Dispatch, SetStateAction, useState } from "react";
import {memo} from 'react';

type Props = {
    note: string;
    octave: number;
    rowIndex: number;
    colIndex: number;
    gridData: { note: string; octave: number; active: boolean; velocity: number }[][];
    setGridData: Dispatch<SetStateAction<{ note: string; octave: number ;active: boolean; velocity: number }[][]>>;
    hoverRowCol: (number | null)[];
    setHoverRowCol: (rowIndex: number | null, colIndex: number | null) => void;
    activeRow: number | null;
    scaleTone: boolean;
    activeKey: string;
    setActiveKey: (note: string) => void;
};

const scrollStep = 5;

const GridCell = (({
    note,
    octave,
    rowIndex,
    colIndex,
    gridData,
    setGridData,
    hoverRowCol,
    setHoverRowCol,
    activeRow,
    scaleTone,
    activeKey,
    setActiveKey
}: Props) => {
    const velocity = gridData[rowIndex][colIndex].velocity;

    const handleClick = () => {
        console.log(activeKey)
        console.log(note)
        setActiveKey(note + octave);
        const active = !gridData[rowIndex][colIndex].active;
        setGridData((prev: any) => {
            const newGridData = [...prev];
            newGridData[rowIndex][colIndex].active = active;
            return newGridData;
        });
    };

    const handleWheel = (e: React.WheelEvent) => {
        if (e.shiftKey) {
            setGridData((prev: any) => {
                const newGridData = [...prev];
                const newVelocity = newGridData[rowIndex][colIndex].velocity + (e.deltaY > 0 ? -scrollStep : scrollStep);
                newGridData[rowIndex][colIndex].velocity = Math.max(0, Math.min(120, newVelocity));
                console.log(newGridData[rowIndex][colIndex].velocity);
                return newGridData;
            });
        }
    };

    return (
        <div
            onClick={handleClick}
            onWheel={handleWheel}
            onMouseOver={() => setHoverRowCol(rowIndex, colIndex)}
            onMouseOut={() => setHoverRowCol(null, null)}
            data-note={note}
            className={`grid-cell 
                        ${activeKey === note + octave && "selected-cell"} 
                        ${scaleTone && "scale-tone-cell"} 
                        ${activeRow === rowIndex && "active-row"}
                        ${(hoverRowCol[0] === rowIndex || hoverRowCol[1] === colIndex) && "hover-row-col"}
                        `}
            style={{ backgroundColor: gridData[rowIndex][colIndex].active ? `rgb(${135 + velocity}, ${velocity % 40}, ${255 - velocity})` : undefined }}
        >
            {note + octave}
        </div>
    );
});

export default memo(GridCell);
